//
// Created by Davide Galbiati on 18/04/2023.
//

#ifndef CHALLENGE2_0_BIS_SOLVERTRAITS_H
#define CHALLENGE2_0_BIS_SOLVERTRAITS_H

#include <functional>
#include <string>
#include <concepts>
#include <vector>
#include <array>
#include "extendedAssert.hpp"

namespace apsc {
    struct SolverTraits {
        using ArgumentType = std::function<double(const double &)>;
        using ResultType = double;
        using VariableType = double;
    };

    struct BisectionOptions {
        double BisectionTol;
    };

    struct QuasiNewtonOptions {
        double QuasiNewtonTol;
        double QuasiNewtonTola;
        unsigned int QuasiNewtonIt;
        SolverTraits::VariableType QuasiNewtonStartingPoint;
    };

    struct SecantOptions {
        double SecantTol;
        double SecantTola;
        unsigned int SecantIt;
    };

    struct Result {
        // The solution
        SolverTraits::ResultType solution;
        // The converging status
        bool converged = false;
    };
}

#endif //CHALLENGE2_0_BIS_SOLVERTRAITS_H
