//
// Created by Alessandra Gotti on 17/04/23.
//

#include "QuasiNewton.h"

apsc::Result apsc::QuasiNewton::solve() const {

    double start = starting_point;
    double ya = function(start);
    double resid = std::abs(ya);
    unsigned int iter{0u};
    double check = tol * resid + tola;
    bool goOn = resid > check;
    while (goOn && iter < maxIt) {
        ++iter;
        start += -ya / derivative(start);
        ya = (function)(start);
        resid = std::abs(ya);
        goOn = resid > check;
    }
    if(start < a || start > b) {
        std::cout << "A zero has been found but does not belong to the chosen interval." << std::endl;
    }
    return {start, (iter < maxIt)};
}





