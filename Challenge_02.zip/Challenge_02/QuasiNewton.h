//
// Created by Alessandra Gotti on 17/04/23.
//

#ifndef CHALLENGE2_0_QUASINEWTON_H
#define CHALLENGE2_0_QUASINEWTON_H

#include "SolverBase.h"
#include "Derivative.h"
#include <tuple>

namespace apsc {

    class QuasiNewton : public SolverBase {

    public:

        //The constructor also instantiates the derivative through the Derivative class
        QuasiNewton(const ArgumentType function, const double& a, const double& b, const double& tol, const double& tola, const unsigned int& maxIt, const double& starting_point) :
                SolverBase(function, a,b), tol(tol), tola(tola), maxIt(maxIt), starting_point(starting_point) {
            this->derivative = derive<1>(function, 1e-4);
        };

        Result solve() const override;

        QuasiNewton() = default;

        ~QuasiNewton() = default;

    private:
        const double tol;
        const double tola;
        const unsigned int maxIt;
        const double starting_point;
        ArgumentType derivative;
    };
}


#endif //CHALLENGE2_0_QUASINEWTON_H
