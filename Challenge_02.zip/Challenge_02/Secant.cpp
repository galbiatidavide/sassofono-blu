//
// Created by Alessandra Gotti on 17/04/23.
//

#include "Secant.h"

apsc::Result apsc::Secant::solve() const {

    double initial = a;
    double final = b;
    double ya = (function)(initial);
    double resid = std::abs(ya);
    double c{initial};
    unsigned int iter{0u};
    double check = tol * resid + tola;
    bool goOn = resid > check;
    while (goOn && iter < maxIt) {
        ++iter;
        double yb = (function)(final);
        c = initial - ya * (final - initial) / (yb - ya);
        double yc = (function)(c);
        resid = std::abs(yc);
        goOn = resid > check;
        ya = yc;
        initial = c;
    }
    if(c < a || c > b) {
        std::cout << "A zero has been found but does not belong to the chosen interval." << std::endl;
    }
    return {c, (iter < maxIt)};
}

