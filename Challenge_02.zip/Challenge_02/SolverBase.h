//
// Created by Alessandra Gotti on 17/04/23.
//

#ifndef CHALLENGE2_0_SOLVERBASE_H
#define CHALLENGE2_0_SOLVERBASE_H

#include "SolverTraits.h"
#include <tuple>

namespace apsc {
    //SolverBase inherits SolverTraits to make it's types available
    class SolverBase : public SolverTraits {

    public:
        //Constructor instantiates the common member data for all derived class and manages a first check on the intervals
        SolverBase(const ArgumentType function, const double& a, const double& b): function{function}, a{a}, b{b}{
            if (a >= b){
                std::cerr << "Fatal error, interval extrema must be coherent... attempt to solve status: aborted" << std::endl;
                exit(1);
            }
        }

        virtual Result solve() const = 0;

        SolverBase() = default;

        virtual ~SolverBase() = default;

    protected:
        const ArgumentType function;
        const double a;
        const double b;
    };
}

#endif //CHALLENGE2_0_SOLVERBASE_H
