//
// Created by Alessandra Gotti on 17/04/23.
//

#include "Bisection.h"

apsc::Result apsc::Bisection::solve() const {

    double initial = a;
    double final = b;
    double ya = function(initial);
    double yb = function(final);
    //This condition might be redundant in view of the use of BracketInterval: we chose to maintain it to do a double check and to preserve the original code
    SURE_ASSERT(ya * yb < 0, "Error: function must change sign at the two end values");
    /*
    //Check if the function does indeed bracket a 0 in the provided interval
    std::tuple<double, double, bool> mytuple = bracketInterval(function, (a + b) / 2., 1.e-6, 200);
    if(std::get<0>(mytuple) < a || std::get<1>(mytuple) > b){

        std::cerr << "Bracket interval did not detect a proper interval to find a 0." << std::endl;
        exit(1);
    }*/
    double delta = final - initial;
    double yc{ya};
    double c{initial};
    while (std::abs(delta) > 2 * tol) {
        c = (initial + final) / 2.;
        yc = (function)(c);
        if (yc * ya < 0.0) {
            yb = yc;
            final = c;
        } else {
            ya = yc;
            initial = c;
        }
        delta = final - initial;
    }
    return {(final + initial) / 2., true};
}
/*
std::tuple<double, double, bool> apsc::Bisection::bracketInterval(ArgumentType const &f, double x1, double h, unsigned int maxIter = 500) const {

    constexpr double expandFactor = 1.5;
    h = std::abs(h);
    // auto          hinit = h;
    auto         direction = 1.0;
    auto         x2 = x1 + h;
    auto         y1 = f(x1);
    auto         y2 = f(x2);
    unsigned int iter = 0u;
    // get initial decrement direction
    while((y1 * y2 > 0) && (iter < maxIter))
    {
        ++iter;
        if(std::abs(y2) > std::abs(y1))
        {
            std::swap(y1, y2);
            std::swap(x1, x2);
            // change direction
        }
        direction = (x2 > x1) ? 1.0 : -1.0;
        x1 = x2;
        y1 = y2;
        x2 += direction * h;
        y2 = f(x2);
        h *= expandFactor;
    }
    return std::make_tuple(x1, x2, iter < maxIter);
}

*/
