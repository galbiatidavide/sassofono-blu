

******************************************************************************************************************************************

As requested, the aim of the challenge is to find the zero of a univariate function solving f(x) = 0.

The programme is based on the provided scheme and consists of a header containing the used types and the options peculiar to each solving metod: Bisection, Quasi-Newton, Regula Falsi, Secant. All the options are read using GetPot library, while the function has been read using muParser (for which a proper class has been used (cfr. provided material)). On the basis of the string read from the text file the programme chooses the constructor to use through the use of variadic version of object factory. In this way it is possible to pass any kind of parameters to the costructor.

Then, the zero is computed and printed, provided that the interval extrema are coherent (first < second), for bisection and Regula Falsi their product is strictly less than 0.

Newton and Secant do not need to handle this situation and are able to find the solution anyway. This solution might not be in the provided interval. In that case a warning message is printed.

REMARK: To verify if a solution is effectively a zero it is important to check the convergence status that must be TRUE. If not, the method has failed and the result is unreliable.

REMARK: The programme is developed taking into account the existance of only one zero in the chosen interval. A priori in multimple zero cases the programme might return a correct result but not all the possible zeros. In fact all these methods can only find one root of the equation.

REMARK: many ways have been explored to create a proper factory but in the end we ended up with a variadic template choice. As a matter of fact, using only Arg... without the template <typename SolverType> does not permit to handle different length costructor. Choosing to use variadic templates could permit to add another solver easily since the factory is very general and a-priori any constructor could be used. Using maps in the factory would require to explicitly add the object with its unchangeable constructor. Another option could have been passing the file to the classes but we decided to keep the "reading/parsing" part in the main.

REMARK: Parsing reduces code efficiency but gains in flexibility so we decided for this way.

REMARK: muParser flags might be regulated properly depending on the user.

REMARK: bisection method is sharper than the others. In fact provides a check on the interval: the extrema must change sign and the existance of a unique root is granted. The other method are in some sense more flexible because they are able to find a zero in an interval independently of the values at the extrema but this root might not be unique. It depends on the starting point of the method. We did not add a check of the extrema in these last case since it's not a theoretically strict hypothesis for the method to work properly. 

******************************************************************************************************************************************


