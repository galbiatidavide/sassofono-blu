//
// Created by Alessandra Gotti on 18/04/23.
//

#ifndef CHALLENGE2_0_SOLVERFACTORY_H
#define CHALLENGE2_0_SOLVERFACTORY_H

#include "SolverBase.h"
#include "Bisection.h"
#include "QuasiNewton.h"
#include "Secant.h"
#include "SolverTraits.h"

#include <memory>
#include <stdexcept>

namespace apsc {

    // This variadic unique_ptr returns a pointer to a generic type catching any number and type of argument.
    template <typename SolverType, typename... Args>
    std::unique_ptr<SolverBase> make_Solver(Args&&... args)
    {
            return std::make_unique<SolverType>(std::forward<Args>(args)...);
    }

    /*
    template <typename... Args>
    std::unique_ptr<SolverBase>
    make_Solver(std::string const &name, Args&&...args)
    {
        if(name == "BISECTION") {


            return std::make_unique<apsc::Bisection>(std::forward<Args>(args)...);}
        if(name == "QUASINEWTON")
            return std::make_unique<apsc::QuasiNewton>(std::forward<Args>(args)...);
        if(name == "REGULAFALSI")
            return std::make_unique<apsc::RegulaFalsi>(std::forward<Args>(args)...);
        if(name == "SECANT") {

            return std::make_unique<apsc::Secant>(std::forward<Args>(args)...);
        }
        return std::unique_ptr<SolverBase>(nullptr);

    }
    */
}

#endif //CHALLENGE2_0_SOLVERFACTORY_H


