//
// Created by Alessandra Gotti on 17/04/23.
//

#ifndef CHALLENGE2_0_SECANT_H
#define CHALLENGE2_0_SECANT_H

#include "SolverBase.h"

namespace apsc {
    class Secant : public SolverBase {

    public:

        Secant(const ArgumentType function, const double& a, const double& b, const double& tol, const double& tola, const unsigned int& maxIt): SolverBase(function, a,b), tol(tol), tola(tola), maxIt(maxIt) {};

        Result solve() const override;

        Secant() = default;

        ~Secant() = default;

    private:
        const double tol;
        const double tola;
        const unsigned int maxIt;
    };
}


#endif //CHALLENGE2_0_SECANT_H
