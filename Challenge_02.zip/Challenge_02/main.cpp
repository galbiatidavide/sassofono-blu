#include <iostream>
#include <functional>
#include "SolverFactory.h"
#include "SolverTraits.h"
#include <cmath>
#include <iomanip>
#include "GetPot"
#include <muParser.h>
#include "muparser_fun.hpp"


int main(int argc, char **argv) {

    // using the required types and namespace

    using namespace apsc;
    //using ArgumentType = SolverTraits::ArgumentType;
    using VariableType = SolverTraits::VariableType;

    //Reading the function, the exact solution, and interval from the .txt file
    GetPot datafile("data_parameters.txt");
    const std::string function_str  = datafile("function", "0.5 - exp(pi * x)");
    const double exact_zero  = datafile("exact_solution", -log(2)/3.14159);
    const VariableType x1 = datafile("x1", -1);
    const VariableType x2 = datafile("x2", 0);

    //Parsing the function
    MuparserFun input(function_str);

    //Reading of the chosen solver
    const std::string solver_str = datafile("solver", "pala");

    const int colWidth = 5;
    std::cout << "Exact result is:        " << std::setw(colWidth) << exact_zero << '\t' << std::endl << std::endl;\

    /*
    ArgumentType input = [](const VariableType &x){
        return 0.5 - exp(pi * x);
    };
    */
    //   VariableType x1{-1};
    //   VariableType x2{0};

    //On the basis of the chosen solver the variadic pointer creates a pointer to the proper derived type through a unique pointer
    //and finds the solution provided the interval is coherent and the solver assumptions are fulfilled.

    if(solver_str == "BISECTION") {
        BisectionOptions bisection_opt{};
        bisection_opt.BisectionTol = datafile("BisectionTol", 1.e-5);
        std::unique_ptr <SolverBase> bisection_ptr = make_Solver<Bisection>(input, x1, x2, bisection_opt.BisectionTol);
        Result bisection_result = bisection_ptr->solve();
        std::cout << "Bisection result is:    " << std::setw(colWidth) << bisection_result.solution << '\t' << "with convergence status: " << std::boolalpha << bisection_result.converged << std::endl;
    }
    else
    if(solver_str == "QUASINEWTON") {
        QuasiNewtonOptions quasi_newton_opt{};
        quasi_newton_opt.QuasiNewtonTol = datafile("QuasiNewtonTol", 1.e-4);
        quasi_newton_opt.QuasiNewtonTola = datafile("QuasiNewtonTola", 1.e-10);
        quasi_newton_opt.QuasiNewtonIt = datafile("QuasiNewtonIt", 150);
        quasi_newton_opt.QuasiNewtonStartingPoint = datafile("QuasiNewtonStartingPoint", 0);
        std::unique_ptr <SolverBase> quasi_newton_ptr = make_Solver<QuasiNewton>(input, x1, x2, quasi_newton_opt.QuasiNewtonTol, quasi_newton_opt.QuasiNewtonTola, quasi_newton_opt.QuasiNewtonIt, quasi_newton_opt.QuasiNewtonStartingPoint);
        Result quasi_newton_result = quasi_newton_ptr->solve();
        std::cout << "Quasi-Newton result is: " << std::setw(colWidth) << quasi_newton_result.solution << '\t' << "with convergence status: " << std::boolalpha << quasi_newton_result.converged << std::endl;
    }
    else
    if(solver_str == "SECANT") {
        SecantOptions secant_opt{};
        secant_opt.SecantTol = datafile("SecantTol", 1.e-4);
        secant_opt.SecantTola = datafile("SecantTola", 1.e-10);
        secant_opt.SecantIt = datafile("SecantIt", 150);
        std::unique_ptr <SolverBase> secant_ptr = make_Solver<Secant>(input, x1, x2, secant_opt.SecantTol, secant_opt.SecantTola, secant_opt.SecantIt);
        Result secant_result = secant_ptr->solve();
        std::cout << "Secant result is:       " << std::setw(colWidth) << secant_result.solution << '\t' << "with convergence status: " << std::boolalpha << secant_result.converged << std::endl;

    }
    else {
        std::cout << "Solver not found" << std::endl;
        return 0;
    }
    return 0;
}


