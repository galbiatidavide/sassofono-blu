//
// Created by Alessandra Gotti on 17/04/23.
//

#ifndef CHALLENGE2_0_BISECTION_H
#define CHALLENGE2_0_BISECTION_H

#include "SolverBase.h"

namespace apsc {
    class Bisection : public SolverBase {

    public:

        Bisection(const ArgumentType function, const double& a, const double& b, const double& tol) : SolverBase(function,a,b), tol{tol} {};

        Result solve() const override;

        Bisection() = default;

        ~Bisection() = default;

        //std::tuple<double, double, bool> bracketInterval(ArgumentType const &f, double x1, double h, unsigned int maxIter) const;

    private:
        const double tol;
    };
}

#endif //CHALLENGE2_0_BISECTION_H
