#include <iostream>
#include <functional>
#include <cmath>
#include <iomanip>
#include <vector>
#include <fstream>
#include <muParser.h>
#include "muparser_fun.hpp"
#include "muparser_fun_exact.hpp"
#include "GetPot"
#include "Compute_solution.h"

int main(int argc, char **argv) {

    // Parsing the forcing term, the exact solution and all necessary parameters
    GetPot datafile("data_parameters.txt");
    const std::string forcing_term_str  = datafile("forcing_term", "-t * exp( -y )");
    const std::string exact_sol_str  = datafile("exact_solution", "log(-0.5*t*t+1)");

    const unsigned int num_steps     = datafile("number_steps", 100);
    const double       initial_datum = datafile("initial_datum", 0);
    const double       theta         = datafile("theta", 0.5);
    /*
    const unsigned int n_max_it      = datafile("n_max_it", 100);
    const double       tol_fun       = datafile("tol_fun", 1.0e-14);
    const double       tol_x         = datafile("tol_x", 1.0e-14);
     */
    const double       final_time    = datafile("final_time", 1);
    const double       starting_time = datafile("starting_time", 0);
    const std::string  filename = datafile("filename", "data_parameters.txt");

    MuparserFun f(forcing_term_str);
    MuparserFunExact exact_solution(exact_sol_str);

    // Call to constructor, convergence. Evaluating norm for a given number of steps.
    Compute_solution solver(f, exact_solution, initial_datum, starting_time, final_time, num_steps, theta);
    solver.solve();
    std::vector<std::vector<double>> sol = solver.get_uh();
    solver.convergence();
    double my_L2_norm = solver.get_L2_norm();
    double my_infinite_norm = solver.get_infinite_norm();

    // First it's decided to show the solution and the norms then the same values are stored in a datafile.dat
    const int colWidth = 12;
    std::cout << std::fixed << std::setprecision(5);

    for(size_t i = 0; i < sol[0].size(); ++i)
        std::cout << "u_h = " << sol[1][i] << std::setw(colWidth) << " at time t_n = " << sol[0][i] << std::endl;

    std::cout << std::endl;
    std::cout << "#L2-norm is       " << my_L2_norm << std::endl;
    std::cout << "#infinite-norm is " << my_infinite_norm << std::endl;
    std::cout << std::endl;
    std::cout << "Result file: result_simple.dat" << std::endl;
    std::ofstream file("result_simple.dat");

    file << "#time\tcomputed solution" << std::endl;
    for(size_t m = 0; m < sol[0].size(); ++m)
    {
        file.setf(std::ios::left, std::ios::adjustfield);
        file.width(16);
        file << sol[0][m] << "\t\t" << sol[1][m] << "\n";
    }
    file << "#L2-norm is    " << my_L2_norm << std::endl;
    file << "#infinite-norm is  " << my_infinite_norm << std::endl;

    // Convergence order: we plot the compute the norms at decreasing time steps.

    std::vector<double> L2_norms;
    std::vector<double> infinite_norms;
    std::vector<double> steps;
    int num = 50;

    for(size_t i = 0; i < 5; ++i){
        Compute_solution solver(f, exact_solution, initial_datum, starting_time, final_time, num, theta);
        solver.solve();
        solver.convergence();
        L2_norms.push_back(solver.get_L2_norm());
        infinite_norms.push_back(solver.get_infinite_norm());
        steps.push_back(solver.get_step());
        num = num * 8;
    }

    // Print the norms of the error vs. time refinment
    std::cout << "Result file: error_simple.dat" << std::endl;
    std::ofstream file2("error_simple.dat");

    for(size_t m = 0; m < L2_norms.size(); ++m)
    {
        file2.setf(std::ios::left, std::ios::adjustfield);
        file2.width(16);
        file2 << steps[m] << "\t\t" << L2_norms[m] << "\t\t" <<infinite_norms[m] << "\n";
    }
    return 0;
}

