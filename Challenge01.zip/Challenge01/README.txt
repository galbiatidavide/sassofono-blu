Approximation of solution of a non linear differential equation.

******************************************************************************************************************************************

As requested, the aim of the challenge is to approximate the solution of a differential equation of type dy/dt = f(t,y) where t is the independent variable, the time, and y is a generic function. The problem is 1D.

The program takes as input the forcing term f, an initial datum y(0), and all the parameters needed to compute the numeric solution and also the analitical solution to compare it with the solution of the algorithm. Then, the method solve() belonging to the class Compute_solution performs the resolution dividing the input time interval in a fixed number of sub-intervals. Depending on the parameter theta passed to the constructor the programme performs backward Euler approximation (theta(1)), forward Euler (theta(0)), Crank-Nicolson (theta(1/2)). The method is based on the resolution of a non linear term using also the Newton method that belongs to newton class, that again makes use of the method in the class Derivative to compute the derivative of a function.

The program has been developed to be able to parse the input terms and all the needed parameters from a simple txt files, so that the user can just change them to have the solution without recompiling. To be more complete, main_very_simple.cpp, simply contains the definitions of the parameters. It's clearly simpler. On the other hand through main_simple.cpp all the parameters are parsed from data_parameters. To do this two additional classes have been implemented muparser_fun, muparser_fun_exact.

Remark: muparser_fun, muparser_fun_exact, newton classes have been used (and adapted) from the available material of the course.

******************************************************************************************************************************************

Running make command, the program is compiled and main_simple and main_very_simple executables are available. 
Just do:

./main_very_simple to output in the bash the solution of the problem at every time t_n. The values are stored in: 

result_very_simple.dat.

Run gnuplot plot_very_simple_script.gnuplot to see the graph of the numeric solution superposed to the real solution.

Also a error_very_simple.dat is produced. This file stores the L2-norm and the infinite_norm depending of the refinement of the time grid (the step). 

Run gnuplot plot_very_simple_error.gnuplot to see a log-log plot to get the order of convergence.

Run ./main_simple to output in the bash the solution of the problem at every time t_n (now the input has been parsed!). The values are stored in: 

result_simple.dat.

Run gnuplot plot_simple_script.gnuplot to see the graph of the numeric solution superposed to the real solution.

Also a error_simple.dat is produced. This file stores the L2-norm and the infinite_norm depending of the refinement of the time grid (the step). 

Run gnuplot plot_simple_error.gnuplot to see a log-log plot to get the order of convergence.

******************************************************************************************************************************************

IMPORTANT REMARK: The makefile makes use of the muParser.h library whose flags have been put in the file. So, please, notice that the paths might depend on the library folder directory.

******************************************************************************************************************************************

IMPORTANT REMARK: THE EXECUTION OF ./main_simple may take 15 seconds (at least on my PC!)

REMARK: getpot library has been used to parse the parameters.

REMARK: errors in the result.dat files are computed at 100 steps. For main_simple.cpp is set in the .txt file at 100 steps (and can be changed), while must be manually changed from main_very_simple.cpp (no parser).
