//
// Created by Davide Galbiati on 23/03/2023.
//

#include "Compute_solution.h"

// Implementation of Crank-Nicolson algorithm
void Compute_solution::solve()
{

    step = (final_time - starting_time) / num_steps;
    // Allocation of the vectors that will compose the solution
    std::vector<double> times{};
    std::vector<double> values{};

    // Definition of the first elements of the solution
    double initial_solution = initial_datum;
    double initial_time = starting_time;
    double future_sol_par{0};

    // Start the cycle pushing the found values in the vectors properly. Implementation follows the instructions given
    for(size_t i = 0; i < num_steps; ++i){
        if(i == 0){
            times.push_back(initial_time);
            values.push_back(initial_solution);
        }else{
            NewtonSolver solver(getF(step, initial_time, initial_time + step, initial_solution, f), getdF(step, initial_time, initial_time + step, initial_solution, f),
                                100, 1000.0, 1000.0);
            solver.solve(initial_solution);
            future_sol_par = solver.get_result();
            initial_solution = future_sol_par + (step * theta) * f(initial_time + step, future_sol_par) + (step * (1 - theta)) * f(initial_time, initial_solution);
            initial_time = initial_time + step;
            times.push_back(initial_time);
            values.push_back(initial_solution);
        }
    }

    // The solution is stored in u_h(private)
    u_h.push_back(times);
    u_h.push_back(values);
}

// getF wraps a lambda function that is useful for Crank-Nicolson (cfr. Challenge instr.). Parameters passed are like: present is t_n, future is t_n+1, present sol. is u_n, f the forcing term.
std::function<double(double)> Compute_solution::getF(const double& step, const double& present, const double& future, const double& present_solution, const std::function<double(const double&, const double&)>& f) const
{
    auto F = [=] (double x) {
        return x - (step / 2) * (f(future, x) + f(present, present_solution)) - present_solution;
    };
    return F;
}

// getdF wraps a lambda function that returns the derivative of a input function (depending of some parameters)
std::function<double(double)> Compute_solution::getdF(const double& step, const double& present, const double& future, const double& present_solution, const std::function<double(const double&, const double&)>& f) const
{
    return derive<1>(getF(step, present, future, present_solution, f), 1e-4);
}

// RMK: derive<1> is necessary for the solver in newton.h that is necessary to find the root of the nonlinear functional

void Compute_solution::convergence()
{

    // Declaration of the variable error and the exact discrete t-eval. solution
    std::vector<double> error{};
    std::vector<double> exact_solution_discrete{};

    // Evaluation of the exact solution at every time in u[0]
    for(size_t i = 0; i < u_h[1].size(); ++i)
        exact_solution_discrete.push_back(exact_solution(u_h[0][i]));

    // Computation of the error: notice that although should be defined positive this is not necessary for the norm eval.
    for(size_t i = 0; i < u_h[1].size(); ++i)
        error.push_back(exact_solution_discrete[i]-u_h[1][i]);

    // Computation of L2 and infinite norms
    L2_norm =  compute_L2_norm(error);
    infinite_norm = compute_infinite_norm(error);
}

// Member function for computation of the norms
double Compute_solution::compute_L2_norm(std::vector<double> const &v) const
{
double norm{0};
for(size_t i = 0; i < v.size(); ++i){
norm += step * (v[i]) * (v[i]);
}
return sqrt(norm);
}

double Compute_solution::compute_infinite_norm(std::vector<double> const &v) const
{
double norm{0};
for(size_t i = 0; i < v.size(); ++i){
double temp = v[i];
if(v[i]<0)
temp = -v[i];
if(temp > norm)
norm = temp;
}
return norm;
}

// Getters
std::vector<std::vector<double>> Compute_solution::get_uh() const
{
    return u_h;
};

double Compute_solution::get_step() const
{
    return step;
};

double Compute_solution::get_L2_norm() const
{
    return L2_norm;
};

double Compute_solution::get_infinite_norm() const
{
    return infinite_norm;
};